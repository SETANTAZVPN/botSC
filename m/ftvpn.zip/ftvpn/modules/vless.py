from ftvpn import *

@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
	async def create_vless_(event):
		async with bot.conversation(chat) as user:
			await event.edit('**𝙐𝙨𝙚𝙧𝙣𝙖𝙢𝙚:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.edit("**𝙌𝙪𝙤𝙩𝙖:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as ip:
			await event.edit("**𝙇𝙞𝙢𝙞𝙩 𝙄𝙋:**")
			ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			ip = (await ip).raw_text
		async with bot.conversation(chat) as exp:
			await event.edit("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 Day ","3"),
Button.inline(" 7 Day ","7")],
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await event.edit("`Processing Crate Premium Account`")
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{ip}" | add-vless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("vless://(.*)",a)]
			print(x)
			# remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("vless://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ Xray/Vless Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Pub Key     :** `{PUB}`
**» Remarks   :** `{user}`
**» Domain    :** `{DOMAIN}`
**» Ns DNS    :** `{HOST}`
**» Port DNS  :** `443, 53`
**» port TLS  :** `443`
**» Port NTLS :** `80, 8080`
**» NetWork   :** `(WS) or (gRPC)`
**» User ID   :** `{uuid}`
**» Path      :** `/whatever/vless`
**» Pub Key   :** `{PUB}`
**◇━━━━━━━━━━━━━◇**
**» Link TLS   : **
`{x[0]}`
**◇━━━━━━━━━━━━━◇**
**» Link NTLS  :**
`{x[1].replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link GRPC  :**
`{x[2].replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Format OpenClash :** `https://{DOMAIN}:81/vless-{user}.txt`
**◇━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**» 🤖@fightertunnell**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vless_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.CallbackQuery(data=b'cek-vless'))
async def cek_vless(event):
	async def cek_vless_(event):
		cmd = 'bash /etc/ftvpn/modules/shell/bot-cek-vless'.strip()
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```{z}```
**Shows Logged In Users Vless**
**» 🤖@fightertunnell**
""",buttons=[[Button.inline("‹🔸Main Menu🔸›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vless_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
	async def delete_vless_(event):
		async with bot.conversation(chat) as user:
			j = """grep -E "^### " "/etc/vless/.vless.db" | cut -d ' ' -f 2-3 | nl -s ') '"""
			g = subprocess.check_output(j, shell=True).decode("ascii")
			await event.respond(g.strip())
			await event.respond("**input number only:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | del-vless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			print(a)
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vless_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
	async def trial_vless_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await event.edit("`Processing Crate Premium Account`")
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | trial-vl'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("vless://(.*)",a)]
			print(x)
			remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("vless://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ Xray/Vless Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Remarks   :** `{remarks}`
**» Domain    :** `{DOMAIN}`
**» Ns DNS    :** `{HOST}`
**» Port DNS  :** `443, 53`
**» port TLS  :** `443`
**» Port NTLS :** `80, 8080`
**» NetWork   :** `(WS) or (gRPC)`
**» User ID   :** `{uuid}`
**» Path      :** `/whatever/vless`
**» Pub Key   :** `{PUB}`
**◇━━━━━━━━━━━━━◇**
**» Link TLS  : **
`{x[0]}`
**◇━━━━━━━━━━━━━◇**
**» Link NTLS :**
`{x[1].replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link GRPC :**
`{x[2].replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Expired Until :** `{exp} Minutes`
**» 🤖@fightertunnell**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vless_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-vless'))
async def renew_vless(event):
	async def renew_vless_(event):
		async with bot.conversation(chat) as user:
			j = """grep -E "^### " "/etc/vless/.vless.db" | cut -d ' ' -f 2-3 | nl -s ') '"""
			g = subprocess.check_output(j, shell=True).decode("ascii")
			await event.respond(g.strip())
			await event.respond("**input number only:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.edit("**𝙌𝙪𝙤𝙩𝙖:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as ip:
			await event.edit("**𝙇𝙞𝙢𝙞𝙩 𝙄𝙋:**")
			ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			ip = (await ip).raw_text
		async with bot.conversation(chat) as exp:
			await event.edit("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 Day ","3"),
Button.inline(" 7 Day ","7")],
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{ip}" | renew-ws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			print(a)
			msg = f"""
**Chnge Vmess Account Successfully
limit Quota {pw} GB limit Login IP {ip} Device
Expired On Account {exp} Day**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_vless_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.CallbackQuery(data=b'mem-vless'))
async def mem_vless(event):
	async def mem_vless_(event):
		cmd = 'bash /etc/ftvpn/modules/shell/bot-mem-vless'.strip()
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""```{z}```
**🤖@fightertunnell**
""",buttons=[[Button.inline("‹🔸Main Menu🔸›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await mem_vless_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
	async def vless_(event):
		inline = [
[Button.inline(" TRIAL VLESS ","trial-vless"),
Button.inline(" CREATE VLESS ","create-vless")],
[Button.inline(" CHECK VLESS ","cek-vless"),
Button.inline(" DELETE VLESS ","delete-vless")],
[Button.inline(" RENEW VLESS ","renew-vless"),
Button.inline(" MEMBER VLESS ","mem-vless")],
[Button.inline("‹🔸Main Menu🔸›","menu")]]
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**◇━━━━━━━━━━━━━◇**
**   🥇VLESS MANAGER🥇** 
**◇━━━━━━━━━━━━━◇**
**✨Service:** `VLESS`
**✨Domain:** `{DOMAIN}`
**✨Isp:** `{z["isp"]}`
**✨City:** `{z["country"]}`
**✨Total User:** `{vls.strip()}` 
**🤖@fightertunnell**
**◇━━━━━━━━━━━━━◇**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vless_(event)
	else:
		await event.answer("access denied ❌",alert=True)
