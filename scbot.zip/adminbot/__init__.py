from telethon import *
import datetime as DT
from telethon import *
import requests,time,os,subprocess,re,sqlite3,sys,random,base64,json,math
import logging
import datetime
import calendar

logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

STRSESI="5579282429"

INTERFACE="eth0"

exec(open("ftvpn/var.txt","r").read())
bot = TelegramClient((SESSIONS),"6","eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)
try:
	open("ftvpn/database.db")
except:
	x = sqlite3.connect("ftvpn/database.db")
	c = x.cursor()
	c.execute("CREATE TABLE admin (user_id)")
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(ADMIN,))
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(USER1,))
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(USER2,))
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(USER3,))
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(USER4,))
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(USER5,))
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(USER6,))
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(USER7,))
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(USER8,))
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(USER9,))
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(USER10,))
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(STRSESI,))
	x.commit()
        
def get_db():
	x = sqlite3.connect("ftvpn/database.db")
	x.row_factory = sqlite3.Row
	return x

def valid(id):
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	if id in a:
		return "true"
	else:
		return "false"
def convert_size(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])

def vnstat_this_month_usage(interface_name):
    stdout = subprocess.getoutput(f"vnstat -s -i {interface_name} --json m")
    j = json.loads(stdout)
    interface = j['interfaces'][0]
    interface_name = interface['name']
    month = j['interfaces'][0]['traffic']['month'][-1]
    rx = month['rx']
    tx = month['tx']
    total = month['rx'] + month['tx']
    month_name = calendar.month_name[month['date']['month']]
    return interface_name, rx, tx, total, month_name

def human_bytes(B):
    """Return the given bytes as a human friendly KB, MB, GB, or TB string."""
    B = float(B)
    KB = float(1024)
    MB = float(KB ** 2)  # 1,048,576
    GB = float(KB ** 3)  # 1,073,741,824
    TB = float(KB ** 4)  # 1,099,511,627,776

    if B < KB:
        return '{0} {1}'.format(B,'Bytes' if 0 == B > 1 else 'Byte')
    elif KB <= B < MB:
        return '{0:.2f} KB'.format(B / KB)
    elif MB <= B < GB:
        return '{0:.2f} MB'.format(B / MB)
    elif GB <= B < TB:
        return '{0:.2f} GB'.format(B / GB)
    elif TB <= B:
        return '{0:.2f} TB'.format(B / TB)