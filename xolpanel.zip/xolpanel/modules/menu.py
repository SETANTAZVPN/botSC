from xolpanel import *
from telethon import Button, events
@bot.on(events.NewMessage(pattern="/start"))
async def start(event):
	await event.reply("Hai Saya Bot MakhlukTunnel SILAHKAN KETIK /menu")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline("[ SSH Menu ]","vpn"),
Button.inline("[ Vmess Menu ]","vmess")],
[Button.inline("[ Vless Menu ]","vless"),
Button.inline("[ Trojan Menu ]","trojan")],
[Button.inline("[ S-Socks Menu ]","shadowsocks"),
Button.inline("[ Other Setting ]","setting")],
[Button.url("[ Order Script Vps ]","https://t.me/mehonk_mt"),
Button.url("[ Wa Group ]","https://chat.whatsapp.com/IYoQTkg2su619CBhTl7wxO")]]
	ox = requests.get(f"https://ipv4.icanhazip.com").text.strip()
	nm= f" curl -sS https://raw.githubusercontent.com/SETANTAZVPN/gatot/main/Name | grep '{ox}'| cut -d ' ' -f3 "
	name = subprocess.check_output(nm, shell=True).decode("ascii").strip()
	xp= f" curl -sS https://raw.githubusercontent.com/SETANTAZVPN/gatot/main/Name | grep '{ox}'| cut -d ' ' -f4 "
	exp = subprocess.check_output(xp, shell=True).decode("ascii").strip()
	bz = f" curl -sS https://raw.githubusercontent.com/SETANTAZVPN/gatot/main/Name | grep '{ox}'| cut -d ' ' -f1 "
	bo = subprocess.check_output(bz, shell=True).decode("ascii").strip()
	if not ox != bo:
		sender = await event.get_sender()
		val = valid(str(sender.id))
		if val == "false":
			try:
				await event.answer("Akses Ditolak", alert=True)
			except:
				await event.reply("Akses Ditolak")
		elif val == "true":
			sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
			ssh = subprocess.check_output(sh, shell=True).decode("ascii")
			vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
			vms = subprocess.check_output(vm, shell=True).decode("ascii")
			vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
			vls = subprocess.check_output(vl, shell=True).decode("ascii")
			tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
			trj = subprocess.check_output(tr, shell=True).decode("ascii")
			s = f' cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l'
			ss = subprocess.check_output(s, shell=True).decode("ascii")
			hap = subprocess.call(["systemctl", "is-active", "--quiet", "haproxy"])
			if(hap == 0):
				hap1 = f'✔️'
			else:
				hap1 = f'✖️'
			ngx = subprocess.call(["systemctl", "is-active", "--quiet", "nginx"])
			if(ngx == 0):
				ngx1 = f'✔️'
			else:
				ngx1 = f'✖️'
			xr = subprocess.call(["systemctl", "is-active", "--quiet", "xray"])
			if(xr == 0):
				xr1 = f'✔️'
			else:
				xr1 - f'✖️'
			sh = subprocess.call(["systemctl", "is-active", "--quiet", "ws@stws"])
			if(sh == 0):
				ws1 = f'✔️'
			else:
				ws1 = f'✖️'
			msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
          **◇⟨ Bot MakhlukTunnel ⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**  HAPROXY  :**  `{hap1}`      ** XRAY     :**  `{xr1}`
**  WS-SOCK  :**  `{ws1}`        **NGINX   :**  `{ngx1}` 
**◇━━━━━━━━━━━━━━━━━━━━━◇**
              **◇⟨ Total Account ⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
** » SSH OVPN        :** `{ssh.strip()}`
** » XRAY VMESS    :** `{vms.strip()}`
** » XRAY VLESS     :** `{vls.strip()}`
** » XRAY TROJAN  :** `{trj.strip()}`
** » XRAY S-SOCKS :** `{ss.strip()}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
** » Bot Version     :** `v1.5` 
** » USER SCRIPT  :** `{name.strip()}`
** » EXP SCRIPT    :** `{exp.strip()}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
			x = await event.edit(msg,buttons=inline)
			if not x:
				await event.reply(msg,buttons=inline)
	else:
		await event.respond(f"** You Dont Have Access**")
