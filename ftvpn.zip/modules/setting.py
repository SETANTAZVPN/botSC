from ftvpn import *

@bot.on(events.CallbackQuery(data=b'vps-info'))
async def info_vps(event):
	async def info_vps_(event):
		cmd = 'bash /etc/ftvpn/modules/shell/bot-vps-info'.strip()
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""```{z}```
**🤖@fightertunnell**
""",buttons=[[Button.inline("‹🔸Main Menu🔸›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await info_vps_(event)
	else:
		await event.answer("access denied ❌",alert=True)


@bot.on(events.CallbackQuery(data=b'reboot'))
async def rebooot(event):
	async def rebooot_(event):
		cmd = f'reboot'
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await event.edit("`Processing Restart Service Server...`")
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		subprocess.check_output(cmd, shell=True)
		await event.edit(f"""
**» REBOOT SERVER**
**» 🤖@fightertunnell**
""",buttons=[[Button.inline("‹🔸Main Menu🔸›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rebooot_(event)
	else:
		await event.answer("access denied ❌",alert=True)


@bot.on(events.CallbackQuery(data=b'resx'))
async def resx(event):
	async def resx_(event):
		cmd = f'systemctl restart xray | systemctl restart nginx | systemctl restart haproxy | systemctl restart server | systemctl restart client'
		subprocess.check_output(cmd, shell=True)
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await event.edit("`Processing Restart Service Server...`")
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await event.edit(f"""
```Processing... 100%\n█████████████████████████ ```
**» Restarting Service Done**
**» 🤖@fightertunnell**
""",buttons=[[Button.inline("‹🔸Main Menu🔸›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await resx_(event)
	else:
		await event.answer("access denied ❌",alert=True)
		
@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest(event):
	async def speedtest_(event):
		cmd = 'speedtest-cli --share'.strip()
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await event.respond(f"""
**
{z}
**
**» 🤖@fightertunnell**
""",buttons=[[Button.inline("‹🔸Main Menu🔸›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await speedtest_(event)
	else:
		await event.answer("access denied ❌",alert=True)


@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
	async def backup_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Input Email:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bash /etc/ftvpn/modules/shell/bot-backup'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Not Exist**")
		else:
			msg = f"""
```
{a}
```
**» 🤖@fightertunnell**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await backup_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.CallbackQuery(data=b'restore'))
async def restsore(event):
	async def rssestore_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Input Token Backup:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bash /etc/ftvpn/modules/shell/bot-restore'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Link Not Exist**")
		else:
			msg = f"""```{z}```
**🤖@fightertunnell**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rssestore_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.CallbackQuery(data=b'backup-restore'))
async def backers(event):
	async def backers_(event):
		inline = [
[Button.inline(" BACKUP","backup"),
Button.inline(" RESTORE","restore")],
[Button.inline("‹🔸Main Menu🔸›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		ver = f" wget -qO- https://github.com/FighterTunnel/tunnel/raw/main/fodder/versi/releases"
		x = subprocess.check_output(ver, shell=True).decode("ascii")
		msg = f"""
**◇━━━━━━━━━━━━━◇**
**   BACKUP & RESTORE**
**◇━━━━━━━━━━━━━◇**
**✨Domain:** `{DOMAIN}`
**✨Isp:** `{z["isp"]}`
**✨City:** `{z["country"]}`
**✨Version :** `{x.strip()}`
**» 🤖@fightertunnell**
**◇━━━━━━━━━━━━━◇**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await backers_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.CallbackQuery(data=b'vnstat'))
async def vnstat(event):
	async def vnstat_(event): 
			interface_name, rx, tx, total, month = vnstat_this_month_usage(interface_name=INTERFACE)
			msg = f"""
**INFORMASI BANDWITH**
⬇️ **Jumlah RX** `{human_bytes(rx)}`
⬆️ **Jumlah TX** `{human_bytes(tx)}`
        **Total :** `{human_bytes(total)}`
**» 🤖@fightertunnell**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vnstat_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.NewMessage(pattern=r"(?:.help|/help|help)$"))
@bot.on(events.CallbackQuery(data=b'help'))
async def helpme(event):
	#async def helpme_(event):
		mes = f"""
✅ **Access:**
/start atau /menu - **Untuk memulai BOT**

⛔️ **Error:**
`systemctl restart botftvpn` - **Untuk merestart BOT**
__Paste Commands di vps dan jalankan__
__ulangi Simple BOT FTVPN__

📝 **Masukan format Crate**
**VMESS, VLESS, TROJAN, SHDWSCK**
**Contoh Format :**
**Username :** `Jhon384`
**Limit Quota :** `30`
**Limit IP :** `10`

📝 **Masukan format Renew**
**VMESS, VLESS, TROJAN, SHDWSCK**
**Contoh Format :**
**Username :** `Jhon384`
**Limit Quota :** `30`
**Limit IP :** `10`
**Note :** `Perhatikan nama pengguna,`
`Anda bisa melihatnya di menu MEMBER`

📝 **Masukan format Crate SSH OVPN**
**Contoh Format :**
**Username :** `Jhon384`
**Password :** `JhoniBau`
**Limit IP :** `10`

__Jika bot terjadi error/tidak respon
anda bisa memulai kembali dengan
merestartnya di vps/server ‼__

🆘 **Support: @fightertunnell**
"""
		await event.respond(mes,buttons=[[Button.inline("‹🔸Main Menu🔸›","menu")],
				   [Button.url("‹🔸𝐃𝐨𝐧𝐚𝐬𝐢🔸›","https://t.me/channel_fightertunnell/52")]])

@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
	async def settings_(event):
		inline = [
[Button.inline(" SPEEDTEST","speedtest"),
Button.inline(" BACKUP & RESTORE ","backup-restore")],
[Button.inline(" REBOOT","reboot"),
Button.inline(" RESTART","resx")],
[Button.inline(" CHECK BANDWITH","vnstat")],
[Button.inline(" HELP COMMANDS","help")],
[Button.inline("‹🔸Main Menu🔸›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		ver = f" wget -qO- https://github.com/FighterTunnel/tunnel/raw/main/fodder/versi/releases"
		x = subprocess.check_output(ver, shell=True).decode("ascii")
		msg = f"""
**◇━━━━━━━━━━━━━◇**
**   🖥OTHER SETTINGS🖥**
**◇━━━━━━━━━━━━━◇**
**✨Domain:** `{DOMAIN}`
**✨Isp:** `{z["isp"]}`
**✨City:** `{z["country"]}`
**✨Version :** `{x.strip()}`
**🤖@fightertunnell**
**◇━━━━━━━━━━━━━◇**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await settings_(event)
	else:
		await event.answer("access denied ❌",alert=True)
