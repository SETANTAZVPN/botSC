from agin import *

@bot.on(events.CallbackQuery(data=b'menu'))
@bot.on(events.NewMessage(pattern="(?: /menu|.menu)$"))
async def menu(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if sender.id in a:
		msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**⟨ ADMIN PANEL MENU ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**🔰 👥Total Member/Reseller:** `{member}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**🤖 Bot Uptime:** `{get_uptime()}`
"""
		z = await event.edit(msg,buttons=[
[Button.inline(" Panel Create Account ","submenu1"),
Button.inline(" Edit Quota Account","quotaq")],
[Button.inline(" Register Member ","register"),
Button.inline(" Delete Member ","delmem")],
[Button.inline(" Add Server ","svmenu"),
Button.inline(" Del Server ","delserver")],
[Button.inline(" Add Saldo To Member ","addsaldo"),
Button.inline(" Min Saldo To Member ","min")]])
		if not z:
			await event.respond(msg,buttons=[
[Button.inline(" Panel Create Account ","submenu1"),
Button.inline(" Edit Quota Account","quotaq")],
[Button.inline(" Register Member ","register"),
Button.inline(" Delete Member ","delmem")],
[Button.inline(" Add Server ","svmenu"),
Button.inline(" Del Server ","delserver")],
[Button.inline(" Add Saldo To Member ","addsaldo"),
Button.inline(" Min Saldo To Member ","min")]])
	else:
		val = valid(sender.id)
		if val == "false":
			try:
				await event.answer("**Akses ditolak ❌**")
			except:
				await event.respond("**Akses Ditolak ❌**")
		else:
			msg = f"""
Halo 👋 {sender.first_name}
Selamat Datang
Silahkan pilih menu dibawah.

Info:
- Free Trial hanya berlaku untuk xray (Vmess, Trojan, Vless) 
Note:
- Wajib test **TRIAL** dahulu sebelum topup/membeli
- Untuk Cek Saldo ke Info Account
Bot Uptime : `{get_uptime()}`
🤖 @xolv4
"""
			x = await event.edit(msg, buttons=[
[Button.inline(" SSH OVPN MANAGER ","ssh-menu")],
[Button.inline(" VMESS MANAGER ","vmess-menu"),
Button.inline(" VLESS MANAGER ","vless")],
[Button.inline(" TROJAN MANAGER ","trwsmenu"),
Button.inline(" SHDWSK MANAGER ","shadowsocks")],
[Button.inline(" 👤INFO ACCOUNT👤 ","info")]]) 
			if not x:
				await event.respond(msg, buttons=[
[Button.inline(" SSH OVPN MANAGER ","ssh-menu")],
[Button.inline(" VMESS MANAGER ","vmess-menu"),
Button.inline(" VLESS MANAGER ","vless-menu")],
[Button.inline(" TROJAN MANAGER ","trwsmenu"),
Button.inline(" SHDWSK MANAGER ","shadowsocks")],
[Button.inline(" 👤INFO ACCOUNT👤 ","info")]]) 
