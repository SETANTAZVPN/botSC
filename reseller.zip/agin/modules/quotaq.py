from agin import *

@bot.on(events.CallbackQuery(data=b'renqutrj'))
async def renqutr(event):
		async def renqutr_(event):
			z = db.execute("SELECT buttonname FROM trojanws").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
					conv = conv.wait_event(events.CallbackQuery)
					buttonname = await conv
					buttonname = buttonname.data.decode("utf-8")
					harga = db.execute("SELECT harga FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					domain = db.execute("SELECT domain FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					
					r = requests.get("http://"+domain+":6969/cektr").text
					all_ = r.split("\n")
					all_list = []
					for x in all_:
						all_list.append("`"+x+"`")
						y = "\n".join(all_list)
						msg = f"""
**  USER LIST TROJAN  **
{y}
**Choose User Number**
"""
					await event.respond(msg)
			async with bot.conversation(event.chat_id) as num:
					await event.edit()
					num = num.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					num = await num
					num = num.message.message
			async with bot.conversation(event.chat_id) as user:
					await event.reply("**Quota: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
					param = f":6969/renqutr?num={num}&quota={user}"
					r = requests.get("http://"+domain+param)
					if r.text != "error":
						try:
							db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
							db.commit()
						except:
							pass
						today = DT.date.today()
						print(r)
						msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
**  Done BANG...!!! Cek Sendiri Di VPS **
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		data = event.data.decode("ascii").split("-")[0]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				val = {"saldo":"100000000"}
				await renqutr_(event)
		else:
			await renqutr_(event)
			
@bot.on(events.CallbackQuery(data=b'renquvms'))
async def renquvm(event):
		async def renquvm_(event):
			z = db.execute("SELECT buttonname FROM vmess").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
					conv = conv.wait_event(events.CallbackQuery)
					buttonname = await conv
					buttonname = buttonname.data.decode("utf-8")
					harga = db.execute("SELECT harga FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					domain = db.execute("SELECT domain FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					
					r = requests.get("http://"+domain+":6969/cekvm").text
					all_ = r.split("\n")
					all_list = []
					for x in all_:
						all_list.append("`"+x+"`")
						y = "\n".join(all_list)
						msg = f"""
**  USER LIST VMESS  **
{y}
**Choose User Number**
"""
					await event.respond(msg)
			async with bot.conversation(event.chat_id) as num:
					await event.edit()
					num = num.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					num = await num
					num = num.message.message
			async with bot.conversation(event.chat_id) as user:
					await event.reply("**Quota: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
					param = f":6969/renquvm?num={num}&quota={user}"
					r = requests.get("http://"+domain+param)
					if r.text != "error":
						try:
							db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
							db.commit()
						except:
							pass
						today = DT.date.today()
						print(r)
						msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
**  Done BANG...!!! Cek Sendiri Di VPS **
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		data = event.data.decode("ascii").split("-")[0]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				val = {"saldo":"100000000"}
				await renquvm_(event)
		else:
			await renquvm_(event)
			
@bot.on(events.CallbackQuery(data=b'quotaq'))
async def quotaq(event):
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if val == "false":
		if sender.id in a:
			await event.edit(buttons=[
[Button.inline("⚡️ EDIT QUOTA VMESS ⚡️","renquvms")],
[Button.inline("⚡️ EDIT QUOTA TROJAN  ⚡️","renqutrj")],
[Button.inline("🔙 Back To Menu",f"menu")]])

			