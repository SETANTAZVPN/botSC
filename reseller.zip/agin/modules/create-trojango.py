from agin import *

@bot.on(events.CallbackQuery(data=b'rentrgo'))
async def rentrgo(event):
		async def rentrgo_(event):
			z = db.execute("SELECT buttonname FROM trojango").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
					conv = conv.wait_event(events.CallbackQuery)
					buttonname = await conv
					buttonname = buttonname.data.decode("utf-8")
					harga = db.execute("SELECT harga FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					domain = db.execute("SELECT domain FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					
					r = requests.get("http://"+domain+":6969/cektrg").text
					all_ = r.split("\n")
					all_list = []
					for x in all_:
						all_list.append("`"+x+"`")
						y = "\n".join(all_list)
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ USER LIST TROJAN  ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
{y}
**Choose User Number**
"""
					await event.respond(msg)
			async with bot.conversation(event.chat_id) as num:
					await event.edit()
					num = num.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					num = await num
					num = num.message.message
			async with bot.conversation(event.chat_id) as user:
					await event.reply("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
#[Button.inline("30 Day","30")],
#[Button.inline("60 Day","60")],
[Button.inline("30 Day","30")]])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
			if int(val["saldo"]) < harga:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				if exp == "30":
					min = harga
				if exp == "60":
					min = harga*2
				if exp == "90":
					min = harga*3
				param = f":6969/rentrg?num={num}&exp={exp}"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						count = db.execute("SELECT counted FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE trojango SET counted = (?) WHERE domain = (?)",
						(int(count)+int(0),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					print(r)
					msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ Successfully Renewed ☘▫️**
**━━━━━━━━━━━━━━━━━━━**

**» Client Name:** `{user}`
**» Expired Until:** `{later}`

**━━━━━━━━━━━━━━━━━━━**
**━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
					dat = {
				"email":val["email"],
                                "protocol":"Renew Trojan-GO",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		data = event.data.decode("ascii").split("-")[0]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				val = {"saldo":"100000000"}
				await rentrgo_(event)
		else:
			await rentrgo_(event)
			
@bot.on(events.CallbackQuery(data=b'trojango-trial'))
async def trojangotrial(event):
		async def trojangotrial_(event):
			z = db.execute("SELECT buttonname FROM trojango").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
				conv = conv.wait_event(events.CallbackQuery)
				buttonname = await conv
				buttonname = buttonname.data.decode("utf-8")
				domain = db.execute("SELECT domain FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				param = f":6969/trial-trgo"
				x = requests.get("http://"+domain+param).text
				if x != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(0),sender.id,))
						count = db.execute("SELECT counted FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE trojango SET counted = (?) WHERE domain = (?)",
						(int(count)+int(0),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(1))
					key = re.search("trojan-go://(.*?)@",x).group(1)
					domain = re.search("@(.*?):",x).group(1)
					port = re.search(domain+":(.*?)/",x).group(1)
					remarks = key
					path = re.search("path=(.*?)&",x).group(1)
					msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ TRIAL Trojan-GO  ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{remarks}`
**🔰 Domain:** `{domain}`
**🔰 Port:** `{port}`
**🔰 Key:** `{key}`
**🔰 WS-Path:** `{path}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TROJAN-GO Url:**
  `{x.strip()}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				await trojangotrial_(event)
		else:
			if str(val["saldo"]) == "0":
				await event.respond('**Saldo Kamu Kosong**')
			else:
				await trojangotrial_(event)
				
@bot.on(events.CallbackQuery(data=b'create-trojango'))
async def trojango(event):
	async def trojango_(event):
		z = db.execute("SELECT buttonname FROM trojango").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			buttonname = await conv
			buttonname = buttonname.data.decode("utf-8")
		harga = db.execute("SELECT harga FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		domain = db.execute("SELECT domain FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		lim = db.execute("SELECT limcounted FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		cont = db.execute("SELECT counted FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		z = requests.get(f"http://ip-api.com/json/{domain}?fields=country,region,city,timezone,isp").json()
		print(domain); print(harga); print(cont); print(lim)
		msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⚜ Informasi Server ⚜**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 ISP:** `{z["isp"]}`
**🔰 Country:** `{z["country"]}`
**🔰 Domain:** `{domain}`
**🔰 Harga:** `{harga}`
**🔰 Total Akun Dibuat:** `{cont}/{lim}`
**━━━━━━━━━━━━━━━━━━━**
** Pilih Ya Untuk Lanjut...!! **
**━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=[
[Button.inline(" Ya ","y"),Button.inline(" Tidak ","n")],
[Button.inline(" 🔙 Back To Menu ","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")
		elif con.data.decode("ascii") == "y":
			async with bot.conversation(event.chat_id) as user:
					await event.edit("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
					
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
[Button.inline("30 Day","30")]])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
			if lim == cont:
				await event.respond("**Server Full**")
			elif int(val["saldo"]) < harga:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				if exp == "30":
					min = harga
				param = f"/create-trgo?user={user}&exp={exp}"
				x = requests.get("http://"+domain+":6969"+param).text
				if x != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						count = db.execute("SELECT counted FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE trojango SET counted = (?) WHERE domain = (?)",
						(int(count)+int(1),domain,))
						db.commit()
					except:
						pass
					#print(r.text)
					#x = r.text
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					key = re.search("trojan-go://(.*?)@",x).group(1)
					domain = re.search("@(.*?):",x).group(1)
					port = re.search(domain+":(.*?)/",x).group(1)
					remarks = key
					path = re.search("path=(.*?)&",x).group(1)
					msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ Trojan-GO ACCOUNT ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{remarks}`
**🔰 Domain:** `{domain}`
**🔰 Port:** `{port}`
**🔰 Key:** `{key}`
**🔰 WS-Path:** `{path}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TROJAN-GO Url:**
  `{x.strip()}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
					
					dat = {
				"email":val["email"],
                                "protocol":"Trojan-GO",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
				else:
					await event.respond("""
_**ERROR**_

**PROBABLY :-** `Username Already Exist`, `Server Error`
""")
		

	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	data = event.data.decode("ascii").split("-")[0]
	if val == "false":
		if sender.id not in a:
			await event.answer("Akses Ditolak")
		else:
			val = {"saldo":"100000000"}
			await trojango_(event)
	else:
		await trojango_(event)

@bot.on(events.CallbackQuery(data=b'trgomenu'))
async def trojangomenu(event):
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	ser = namasgo()
	har = hargasgo()
	serv = []
	for x, y in zip(ser, har):
		print(x, y)
		serv.append(f"**🔰 {x}  ** `Rp.{y}`\n")
	if val == "false":
		if sender.id in a:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⚜ Trojan-GO Account Menu ⚜**
**━━━━━━━━━━━━━━━━━━━**
**         💶  Price List  💶** 
** **
{"".join(serv)}


**━━━━━━━━━━━━━━━━━━━**
"""
			await event.edit(msg, buttons=[
[Button.inline("☘ Created Trojan-GO ☘","create-trojango"),
Button.inline("☘ Created Trial Trojan-GO ☘","trojango-trial")],
[Button.inline("☘ Renew Trojan-GO Account ☘","rentrgo")],
[Button.inline("🔙 Back To Menu",f"menu")]])
		else:
			await event.answer("Akses Ditolak ❌")
	else:
		msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⚜ Trojan-GO Account Menu ⚜**
**━━━━━━━━━━━━━━━━━━━**
**         💶  Price List  💶** 
** **
{"".join(serv)}


**━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg, buttons=[
[Button.inline("☘ Created Trojan-GO ☘","create-trojango"),
Button.inline("☘ Created Trial Trojan-GO ☘","trojango-trial")],
[Button.inline("☘ Renew Trojan-GO Account ☘","rentrgo")],
[Button.inline("🔙 Back To Menu",f"menu")]])
