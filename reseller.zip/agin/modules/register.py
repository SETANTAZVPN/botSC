from agin import *

@bot.on(events.CallbackQuery(data=b'register'))
async def register(event):
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		async with bot.conversation(event.chat_id) as id:
			await event.respond("**User ID: **")
			id = id.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			id = await id
			id = id.message.message
		async with bot.conversation(event.chat_id) as saldo:
			await event.respond("**Saldo: **")
			saldo = saldo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			saldo = await saldo
			saldo = saldo.message.message
		async with bot.conversation(event.chat_id) as email:
			await event.respond("**Email:**")
			email = email.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			email = await email
			email = email.message.message
		z = db.execute("INSERT INTO user (member,saldo,email) VALUES (?,?,?)",
		(id,saldo,email,))
		db.commit()
		await event.respond(f"""
**━━━━━━━━━━━━━━━━**
**⟨ Registrasi Sukses ⟩**
**━━━━━━━━━━━━━━━━**
**» User ID:** `{id}`
**» Saldo:** `{saldo}`
**» Email Reseller:** `{email}`
**━━━━━━━━━━━━━━━━**
""")